const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");

const app = express();

// ==============================
// CONFIGURACIONES
// ==============================
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(express.static(path.join(__dirname, "public")));
app.use(bodyParser.urlencoded({ extended: true }));

// =====================================
// GENERADOR DE CÓDIGOS DE FORMULARIOS
// =====================================
let contadorFormularios = 1;

function generarCodigoFormulario() {
    const año = new Date().getFullYear();
    const correlativo = String(contadorFormularios++).padStart(5, "0");
    return `LLE-${año}-${correlativo}`;
}

// ==============================
// RUTAS
// ==============================

// Página 1 del formulario
app.get("/", (req, res) => {
    const codigo = generarCodigoFormulario();
    res.render("index", { codigo });
});

// Página 2 del formulario
app.post("/page2", (req, res) => {
    res.render("page2", { page1Data: req.body });
});

// Vista previa / resumen final
app.post("/preview", (req, res) => {
    const allData = {
        ...req.body,
        ...req.body.page1Data
    };
    res.render("pdf-preview", { data: allData });
});

// ==============================
// INICIAR SERVIDOR
// ==============================
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});