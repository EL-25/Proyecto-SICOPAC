-- Crear la base de datos
CREATE DATABASE FormularioDB;
GO

USE FormularioDB;
GO

-- Crear tabla para almacenar los registros
CREATE TABLE Formularios (
    Id INT IDENTITY(1,1) PRIMARY KEY,          -- Identificador del registro
    NumeroFormulario AS (FORMAT(Id, '00000'))  -- Generador automático tipo 00001, 00002...
        PERSISTED,
    
    NombreSolicitante NVARCHAR(150) NOT NULL,
    Municipio NVARCHAR(100) NOT NULL,
    Distrito NVARCHAR(100) NOT NULL,
    FechaPresentacion DATE NOT NULL,
    HoraPresentacion TIME NULL,
    Telefono NVARCHAR(20) NULL,
    Correo NVARCHAR(120) NULL,
    Declaraciones NVARCHAR(MAX) NULL,
    DescripcionDocumentacion NVARCHAR(MAX) NULL,
    
    FechaRegistro DATETIME DEFAULT GETDATE()   -- Cuándo se guardó en BD
);
GO
